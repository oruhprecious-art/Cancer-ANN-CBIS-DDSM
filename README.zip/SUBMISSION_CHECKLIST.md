# GitHub Submission Checklist

- [ ] Upload the Python source files.
- [ ] Include README.md and requirements.txt.
- [ ] Add final CSV results to `results/`.
- [ ] Add final figures to `figures/`.
- [ ] Do NOT upload the full CBIS-DDSM image dataset.
- [ ] Do NOT upload private patient information.
- [ ] Test the repository instructions.
- [ ] Create the GitHub repository.
- [ ] Copy the repository URL into the Nexford submission.
- [ ] Include the AI Disclosure Form.
