# Cancer ANN Project – CBIS-DDSM

## Project Overview
This project demonstrates an Artificial Neural Network (CNN-based ANN) using TensorFlow/Keras to classify mammography images as malignant or non-malignant.

## Dataset
The project uses the Curated Breast Imaging Subset of the Digital Database for Screening Mammography (CBIS-DDSM). The full image dataset is not included in this repository.

## Target Definition
- MALIGNANT → 1
- BENIGN → 0
- BENIGN_WITHOUT_CALLBACK → 0

This binary transformation was a modelling decision for the project.

## Workflow
1. Inspect dataset and metadata.
2. Map lesion records to mammography images.
3. Audit missing values, image quality and duplicates.
4. Create patient-level training, validation and test splits.
5. Resize images to 224 × 224, convert to grayscale and normalize pixels to 0–1.
6. Train a baseline CNN.
7. Train an improved CNN using augmentation, Batch Normalization, dropout and training controls.
8. Train Model V3 as an additional experiment.
9. Evaluate accuracy, precision, recall, F1-score, specificity, confusion matrix and ROC-AUC.

## Repository Structure
```text
Cancer_ANN_Project/
├── README.md
├── requirements.txt
├── inspection.py
├── dataset_analysis.py
├── mapping_check.py
├── test_mapping_check.py
├── preprocessing_audit.py
├── preprocessing_test.py
├── build_datasets.py
├── patient_split.py
├── baseline_model.py
├── improved_model.py
├── model_v3.py
├── evaluate_v3.py
├── tune_threshold.py
├── analyze_predictions.py
├── results/
└── figures/
```

## Final Dataset Split

| Dataset | Images | Non-Malignant | Malignant |
|---|---:|---:|---:|
| Training | 2,465 | 1,442 | 1,023 |
| Validation | 568 | 337 | 231 |
| Final Test | 534 | 331 | 203 |

The split was performed at the patient level to reduce data leakage.

## Baseline Results
- Accuracy: 52.81%
- Precision: 36.31%
- Recall: 32.02%
- F1-score: 34.03%
- Specificity: 65.56%
- ROC-AUC: 0.4812

## Improved Model
The improved model used four convolutional blocks, Batch Normalization, Global Average Pooling, data augmentation, dropout, class weighting, Early Stopping and ReduceLROnPlateau.

Using a validation-selected threshold of 0.40, the final test results were:
- Accuracy: 38.95%
- Precision: 38.37%
- Recall: 100.00%
- F1-score: 55.46%
- Specificity: 1.51%
- ROC-AUC: 0.5235

The high recall was accompanied by many false positives, so the model is an academic research prototype and is not suitable for clinical diagnosis.

## Model V3
Model V3 investigated more conservative augmentation and removal of class weighting.
- Total parameters: 423,297
- Trainable parameters: 422,081
- Best validation epoch: 3
- Validation loss: 0.6774
- Validation accuracy: 57.75%
- Validation precision: 46.34%
- Validation recall: 24.68%
- Test ROC-AUC: 0.5459

## Reproducibility
Recommended environment:
- Python 3.12
- TensorFlow 2.21.0
- NumPy
- Pandas
- Pillow
- Matplotlib
- Scikit-learn

Install dependencies:
```bash
pip install -r requirements.txt
```

## Important Note
Do not upload the full mammography image dataset or private patient information to GitHub. Configure the local dataset path in the scripts before execution.

## AI Disclosure
AI tools were used as a learning and development assistant for coding guidance, debugging, interpretation of model outputs and report refinement. Suggestions were tested in the local Python environment, and the reported results were based on the actual experiments.

## Author
**Oruh Precious**  
MSc Business Analytics  
Nexford University
